package testing;

public class HistoricalPrice {
	String date;
	int product_id;
	float price;
	
	public HistoricalPrice(String date, int id, float price) {
		this.date = date;
		this.product_id = id;
		this.price = price;
	}
	
	public String toString() {
		return date+"|"+product_id+"|"+price;
	}
}
