package testing;

public class Order {
	int order_id;
	int bronco_id;
	String status;
	
	public Order(int oid, int bid, String status) {
		this.order_id = oid;
		this.bronco_id = bid;
		this.status = status;
	}
	
	public String toString() {
		return "" + order_id +"|"+bronco_id+"|"+status;
	}
}
