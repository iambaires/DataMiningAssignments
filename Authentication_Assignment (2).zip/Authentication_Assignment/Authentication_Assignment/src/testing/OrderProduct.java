package testing;

public class OrderProduct {
	int order_id;
	int product_id;
	float price;
	int quantity;
	
	public OrderProduct(int oid, int pid, float price, int quantity) {
		this.order_id = oid;
		this.product_id = pid;
		this.price = price;
		this.quantity = quantity;
	}
	
	public String toString() {
		return "" + order_id +"|"+product_id+"|"+price+"|"+quantity;
	}
}
