package testing;

public class Tuple<T, K> {
	
	private T obj1;
	private K obj2;
	
	public Tuple (T obj1, K obj2) {
		this.obj1 = obj1;
		this.obj2 = obj2;
	}
	
	public T getFirst() {
		return obj1;
	}
	
	public K getSecond() {
		return obj2;
	}
	
}
