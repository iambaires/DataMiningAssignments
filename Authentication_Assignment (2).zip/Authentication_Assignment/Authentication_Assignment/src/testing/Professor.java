package testing;

public class Professor {
	int bronco_id;
	String department;
	String research;
	String office;
	
	public Professor(int id, String department, String research, String office) {
		this.bronco_id = id;
		this.department = department;
		this.research = research;
		this.office = office;
	}
	
	public String toString() {
		return "" + bronco_id+"|"+department+"|"+research+"|"+office;
	}
}
