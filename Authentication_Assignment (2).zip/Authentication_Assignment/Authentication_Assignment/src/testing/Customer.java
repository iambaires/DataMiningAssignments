package testing;

public class Customer {
	private int broncoID;
	private String firstName;
	private String lastName;
	private int phone;
	private String address;
	private String dob;
	private float discount;
	
	public Customer(int id, String fName, String lName, int phone, String address, String dob, float discount) {
		this.broncoID=id;
		this.firstName=fName;
		this.lastName=lName;
		this.phone=phone;
		this.address = address;
		this.dob=dob;
		this.discount=discount;
	}
	
	public String toString() {
		return broncoID+"|"+firstName+"|"+lastName+"|"+phone+"|"+address+"|"+dob+"|"+discount;
	}

	public int getBroncoID() {
		return broncoID;
	}

	public void setBroncoID(int bronco_id) {
		this.broncoID = bronco_id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String first_name) {
		this.firstName = first_name;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String last_name) {
		this.lastName = last_name;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public float getDiscount() {
		return discount;
	}

	public void setDiscount(float discount) {
		this.discount = discount;
	}
	
}
