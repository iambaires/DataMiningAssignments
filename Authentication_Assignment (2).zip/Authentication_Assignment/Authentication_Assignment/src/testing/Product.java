package testing;

public class Product {
	
	private int productId;
	private String name;
	private String description;
	
	public Product(int productID, String name, String description) {
		this.productId = productID;
		this.name = name;
		this.description = description;
	}
	
	public int getProductId() {
		return this.productId;
	}

	public void setProductID(int productID) {
		this.productId = productID;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return productId+"|"+name+"|"+description;
	}
	
	
}
