package testing;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;


public class DatabaseController {
	
	private final static String[] DEFAULT = {"jdbc:postgresql://localhost:5432/postgres", "postgres", "8790"};
	private String URL;
	private String USER;
	private String PWD;	
	
	private static DatabaseController instance = null;
	
	private DatabaseController(String URL, String USER, String PWD) {
		this.URL = URL;
		this.USER = USER;
		this.PWD = PWD;
	}
		
	public static DatabaseController getInstance() {
		if (instance == null) {
			instance = new DatabaseController(DEFAULT[0], DEFAULT[1], DEFAULT[2]);
		}
		return instance;
	}
		
	private ArrayList<String> getListFile(String filename) {
		ArrayList<String> list = new ArrayList<>();
		try {
			File f = new File(filename);
			FileReader fr = new FileReader(f);
			BufferedReader br = new BufferedReader(fr);
			String line = br.readLine();
			while(line != null) {
				list.add(line);
				line = br.readLine();
			}
			br.close();
		} catch (Exception e) {
			System.out.println(e);
		}
		return list;
	}
	
	private ResultSet query(String statement) throws ClassNotFoundException, SQLException {
		Connection connection = DriverManager.getConnection(URL, USER, PWD);
		ResultSet rs = connection.prepareStatement(statement).executeQuery();
		connection.close();
		return rs;
	}	
	
	private void executeCommands(ArrayList<String> commands) throws ClassNotFoundException, SQLException {
		Connection connection = DriverManager.getConnection(URL, USER, PWD);
		Statement statement = connection.createStatement();
		for (String sql : commands) {
			statement.executeUpdate(sql);
		}
		statement.close();
		connection.close();
	}
	
	public ArrayList<Customer> getCustomer(String clause) throws ClassNotFoundException, SQLException {
		ArrayList<Customer> list = new ArrayList<>();
		String sql = "SELECT * FROM customer " + clause;
		ResultSet rs = query(sql);
		boolean next = rs.next();
		while(next) {
			int bronco_id = rs.getInt("bronco_id");
			String first_name = rs.getString("first_name");
			String last_name = rs.getString("last_name");
			int phone = rs.getInt("phone");
			String address = rs.getString("address");
			String dob = rs.getString("date_of_birth");
			float discount = rs.getFloat("discount");
			
			Customer c = new Customer(bronco_id, first_name, last_name, phone, address, dob, discount);
			list.add(c);
			next = rs.next();
		}
		return list;
	}
	
	public ArrayList<Student> getStudent(String clause) throws ClassNotFoundException, SQLException {
		ArrayList<Student> list = new ArrayList<>();
		String sql = "SELECT * FROM student" + clause;
		ResultSet rs = query(sql);
		boolean next = rs.next();
		while(next) {
			int bronco_id = rs.getInt("bronco_id");
			String entry_date = rs.getString("entry_date");
			String graduation_date = rs.getString("graduation_date");
			String major = rs.getString("major");
			String minor = rs.getString("minor");
			Student s = new Student(bronco_id, entry_date, graduation_date, major, minor);
			list.add(s);
			next = rs.next();
		}
		rs.close();
		return list;
	}

	public ArrayList<Order> getOrder(String clause) throws ClassNotFoundException, SQLException {
		ArrayList<Order> list = new ArrayList<>();
		String sql = "SELECT * FROM order_1" + clause;
		ResultSet rs = query(sql);
		boolean next = rs.next();
		while(next) {
			int order_id = rs.getInt("order_id");
			int bronco_id = rs.getInt("bronco_id");
			String status = rs.getString("status");
			Order o = new Order(order_id, bronco_id, status);
			list.add(o);
			next = rs.next();
		}
		rs.close();
		return list;
	}

	public ArrayList<Professor> getProfessor(String clause) throws ClassNotFoundException, SQLException {
		ArrayList<Professor> list = new ArrayList<>();
		String sql = "SELECT * FROM professor" + clause;
		ResultSet rs = query(sql);
		boolean next = rs.next();
		while(next) {
			int bronco_id = rs.getInt("bronco_id");
			String department = rs.getString("department");
			String research = rs.getString("research");
			String office = rs.getString("office");
			Professor p = new Professor(bronco_id, department, research, office);
			list.add(p);
			next = rs.next();
		}
		rs.close();
		return list;
	}
	
	public ArrayList<Product> getProduct(String clause) throws ClassNotFoundException, SQLException {
		ArrayList<Product> list = new ArrayList<>();
		String sql = "SELECT * FROM product" + clause;
		ResultSet rs = query(sql);
		boolean next = rs.next();
		while(next) {
			int product_id = rs.getInt("product_id");
			String name = rs.getString("name");
			String description = rs.getString("description");
			Product p = new Product(product_id, name, description);
			list.add(p);
			next = rs.next();
		}
		rs.close();
		return list;
	}
	
	// Inserts into historical_price. 1 new price for 1 product.
	public void changePrice(String date, int product_id, float price) throws ClassNotFoundException, SQLException {
		ArrayList<String> commands = new ArrayList<>();
		commands.add("insert into historical_price (date, product_id_hp, price) values ('"+date+"', "+product_id+", "+price+");");
		executeCommands(commands);
		
	}

	// Get most recent price for 1 product.
	public float getMostRecentPrice(int product_id) throws ClassNotFoundException, SQLException {
		ArrayList<HistoricalPrice> list = getHistoricalPrice(" WHERE product_id_hp = "+product_id);
		HistoricalPrice first = list.get(0);
		float currentPrice = first.price;
		LocalDate mostRecentDate = LocalDate.parse(first.date);
		
		for (int i = 1; i < list.size(); i++) {
			HistoricalPrice hp = list.get(i);
			LocalDate curDate = LocalDate.parse(hp.date);
			if (curDate.isAfter(mostRecentDate)) {
				currentPrice = hp.price;
				mostRecentDate = curDate;
			}
		}
		return currentPrice;
	}
	
	
	// For 1 product, get their dates and prices as a Tuple list
	public Tuple<ArrayList<String>, ArrayList<Double>> getOneProductDatePrices(int product_id) throws ClassNotFoundException, SQLException {
		ArrayList<String> dates = new ArrayList<>();
		ArrayList<Double> prices = new ArrayList<>();
		
		ArrayList<HistoricalPrice> hpList = getHistoricalPrice(" WHERE product_id_hp = " + product_id);
		for (HistoricalPrice hp : hpList) {
			dates.add(hp.date);
			prices.add((double)hp.price);
		}
				
		return new Tuple<ArrayList<String>, ArrayList<Double>>(dates, prices);
	}

	public ArrayList<HistoricalPrice> getHistoricalPrice(String clause) throws ClassNotFoundException, SQLException {
		ArrayList<HistoricalPrice> list = new ArrayList<>();
		String sql = "SELECT * FROM historical_price" + clause;
		ResultSet rs = query(sql);
		boolean next = rs.next();
		while(next) {
			String date = rs.getString("date");
			int product_id = rs.getInt("product_id_hp");
			float price = rs.getFloat("price");
			HistoricalPrice hp = new HistoricalPrice(date, product_id, price);
			list.add(hp);
			next = rs.next();
		}
		rs.close();
		return list;
	}

	public ArrayList<OrderProduct> getOrderProduct(String clause) throws ClassNotFoundException, SQLException {
		ArrayList<OrderProduct> list = new ArrayList<>();
		String sql = "SELECT * FROM order_product" + clause;
		ResultSet rs = query(sql);
		boolean next = rs.next();
		while(next) {
			int order_id = rs.getInt("order_id");
			int product_id = rs.getInt("product_id_op");
			float price = rs.getFloat("price");
			int quantity = rs.getInt("quantity");
			OrderProduct op = new OrderProduct(order_id, product_id, price, quantity);
			list.add(op);
			next = rs.next();
		}
		rs.close();
		return list;
	}
	
	// New products must have at least 1 historical price.
	public void registerNewProduct(Product p, HistoricalPrice hp) throws ClassNotFoundException, SQLException {
		if (p.getProductId() == hp.product_id) {
			ArrayList<String> commands = new ArrayList<>();
			String desc = null;
			if (p.getDescription() != null) {
				desc = "'"+p.getDescription()+"'";
			}
			commands.add("insert into product (product_id, name, description) values ("+p.getProductId()+", '"+p.getName()+"', "+desc+");");		
			commands.add("insert into historical_price (date, product_id_hp, price) values ('"+hp.date+"', "+hp.product_id+", "+hp.price+");");		
			executeCommands(commands);
		}
	}
	
	// Can register Customer, Student, Professor at same time.
	public void registerNewUser(Customer c, Student s, Professor p) throws ClassNotFoundException, SQLException {
		ArrayList<String> commands = new ArrayList<>();
		commands.add("insert into customer (bronco_id, first_name, last_name, phone, address, date_of_birth, discount) values ("
				+c.getBroncoID()+", '"+c.getFirstName()+"', '"+c.getLastName()+"', "+c.getPhone()+", '"+c.getAddress()+"', '"+c.getDob()+"', "+c.getDiscount()+");");
		
		// Some attributes can be null, need to account for them. Apostrophe not needed for nulls.
		if (s != null && c.getBroncoID() == s.bronco_id) {
			String gDate = "null";
			String minor = "null";
			if (s.grad_date != null) {
				gDate = "'"+s.grad_date+"'";
			}
			if (s.minor != null) {
				minor = "'"+s.minor+"'";
			}
			
			commands.add("insert into student (bronco_id, entry_date, graduation_date, major, minor) values ("
				+s.bronco_id+", '"+s.entry_date+"', "+gDate+", '"+s.major+"', "+minor+");");			
		}
		
		if (p != null && c.getBroncoID() == s.bronco_id) {
			commands.add("insert into professor (bronco_id, department, research, office) values ("
				+p.bronco_id+", '"+p.department+"', '"+p.research+"', '"+p.office+"');");
		}
		
		executeCommands(commands);
	}
	
	// Orders require some products. List should have arrays of p[0] = product_id, p[1] = price, p[2] = quantity
	public void registerNewOrder(Order o, ArrayList<String[]> cart) throws ClassNotFoundException, SQLException {
		ArrayList<String> commands = new ArrayList<>();
		commands.add("insert into order_1 (order_id, bronco_id, status) values ("+o.order_id+", "+o.bronco_id+", '"+o.status+"');");
		for (String[] p : cart) {
			commands.add("insert into order_product (order_id, product_id_op, price, quantity) values ("+o.order_id+", "+p[0]+", "+p[1]+", "+p[2]+");");
		}		
		executeCommands(commands);
	}
		
	// Only run once. Need to have the related files in the project directory.
	public void initDB() throws ClassNotFoundException, SQLException {
		ArrayList<String> commands = new ArrayList<>();		
		ArrayList<String> listOfCustomers = getListFile("customers.txt");
		ArrayList<String> listOfStudents = getListFile("students.txt");
		ArrayList<String> listOfProfessors = getListFile("professors.txt");
		ArrayList<String> listOfProducts = getListFile("products.txt");
		ArrayList<String> listOfHistoricalPrices = getListFile("historical_price.txt");
		ArrayList<String> listOfOrders = getListFile("orders.txt");
		ArrayList<String> listOfOrderProducts = getListFile("order_product.txt");
		
		for (String line : listOfCustomers) {
			String[] arr = line.split("\\|");
			String values = arr[0]+", '"+arr[1]+"', '"+arr[2]+"', "+arr[3]+", '"+arr[4]+"', '"+arr[5]+"', "+arr[6];
			commands.add("insert into customer (bronco_id, first_name, last_name, phone, address, date_of_birth, discount) "
					+ "values ("+values+");");
		}
		for (String line : listOfStudents) {
			String[] arr = line.split("\\|");

			String values = arr[0]+", '"+arr[1]+"', '"+arr[2]+"', '"+arr[3]+"', '"+arr[4]+"'";
			commands.add("insert into student (bronco_id, entry_date, graduation_date, major, minor) "
					+ "values ("+values+");");
		}
		for (String line : listOfProfessors) {
			String[] arr = line.split("\\|");

			String values = arr[0]+", '"+arr[1]+"', '"+arr[2]+"', '"+arr[3]+"'";
			commands.add("insert into professor (bronco_id, department, research, office) "
					+ "values ("+values+");");
		}
		for (String line : listOfProducts) {
			String[] arr = line.split("\\|");

			String values = arr[0]+", '"+arr[1]+"', '"+arr[2]+"'";
			commands.add("insert into product (product_id, name, description) "
					+ "values ("+values+");");
		}
		for (String line : listOfHistoricalPrices) {
			String[] arr = line.split("\\|");

			String values = "'"+arr[0]+"', "+arr[1]+", "+arr[2];
			commands.add("insert into historical_price (date, product_id_hp, price) "
					+ "values ("+values+");");
		}
		for (String line : listOfOrders) {
			String[] arr = line.split("\\|");

			String values = arr[0]+", "+arr[1]+", '"+arr[2]+"'";
			commands.add("insert into order_1 (order_id, bronco_id, status) "
					+ "values ("+values+");");
		}
		for (String line : listOfOrderProducts) {
			String[] arr = line.split("\\|");

			String values = arr[0]+", "+arr[1]+", "+arr[2]+", "+arr[3];
			commands.add("insert into order_product (order_id, product_id_op, price, quantity) "
					+ "values ("+values+");");
		}
		
		executeCommands(commands);
	}
}
