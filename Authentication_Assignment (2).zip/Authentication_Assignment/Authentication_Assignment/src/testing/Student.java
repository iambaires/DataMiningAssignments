package testing;

public class Student {
	int bronco_id;
	String entry_date;
	String grad_date;
	String major;
	String minor;
	
	public Student(int id, String eDate, String gDate, String major, String minor) {
		this.bronco_id=id;
		this.entry_date=eDate;
		this.grad_date=gDate;
		this.major=major;
		this.minor=minor;
	}
	
	public String toString() {
		return "" + bronco_id +"|"+entry_date+"|"+grad_date+"|"+major+"|"+minor;
	}
}
