package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import model.dataccess.DataAccess;
import model.entities.MessageException;
import testing.Customer;
import testing.DatabaseController;

@SuppressWarnings("serial")
public class LoginView extends JFrame implements ActionListener {

	private JLabel lblBroncoID;
	
	private JButton buttonSubmit, buttonClean;

	private JTextField txtBroncoID;

	private JPanel panel1, panel3;
	
	public LoginView() {

		this.initializeComponents();

		this.buildUI();
	}

	private void initializeComponents() {
		
		this.lblBroncoID = new JLabel("Bronco ID:   ");

		this.buttonSubmit = new JButton("Submit");
		this.buttonSubmit.addActionListener(this);

		this.buttonClean = new JButton("Clean");
		this.buttonClean.addActionListener(this);

		this.txtBroncoID = new JTextField(23);

		this.panel1 = new JPanel();
		this.panel1.setLayout(new FlowLayout(FlowLayout.CENTER));


		this.panel3 = new JPanel();
		this.panel3.setLayout(new FlowLayout(FlowLayout.CENTER));

	}

	private void buildUI() {

		this.panel1.add(this.lblBroncoID);
		this.panel1.add(this.txtBroncoID);

		this.panel3.add(this.buttonSubmit);
		this.panel3.add(this.buttonClean);

		this.getContentPane().add(panel1, BorderLayout.NORTH);
		this.getContentPane().add(panel3, BorderLayout.SOUTH);

		this.setTitle("Authentication");
		this.setBounds(350, 140, 550, 200);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setResizable(false);
		this.setVisible(true);
	}

	public static void main(String[] args) {
		new LoginView();
	}

	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == this.buttonSubmit) {
			String broncoID = "";
			String firstName = "";
			DatabaseController dbc = DatabaseController.getInstance();
			try {
				
				
				broncoID = txtBroncoID.getText();
				
				if (broncoID.isBlank()) {
					throw new MessageException("Bronco ID not informed.");
				}
				
				String query = "WHERE bronco_id = " + broncoID;
				
				System.out.println(query);
				
				ArrayList<Customer> customers = dbc.getCustomer(query);
				System.out.println(customers);
				Customer customer = customers.get(0);
				System.out.println(customer);
				
				
				firstName = customer.getFirstName();
			
				if (firstName.isBlank()) {
					throw new MessageException("Incorrect credentials.");
				}
				
				new LoginSuccessView(firstName, Integer.valueOf(broncoID));
				dispose();
				
				
			} catch (MessageException e) {
				JOptionPane.showMessageDialog (null, e.getMessage());
			} catch (ClassNotFoundException e) {
				JOptionPane.showMessageDialog (null, e.getMessage());
			} catch (SQLException e) {
				JOptionPane.showMessageDialog (null, e.getMessage());
			}
		} else {
			this.txtBroncoID.setText("");
		}
	}
	
}
