package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.*;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.*;

import testing.Product;

public class SearchResults extends JFrame implements ActionListener {

    private static final long serialVersionUID = 1L;
    private JTable table;
    private JButton buttonSubmit;
    private JPanel panel1;
    private int broncoID;
    private ArrayList<Float> prices;
    
    HashMap<Integer, Product> orderMap = new HashMap<Integer, Product>();;

    public SearchResults(ArrayList<Product> products, int broncoID, ArrayList<Float> prices) {
    	this.prices = prices;
    	this.broncoID = broncoID;
		
		String[] columnNames = {"ID", "Name", "Price", "Description", "Add Item"};
		
		Object[][] data = new Object[products.size()][columnNames.length];

		int row = 0;
		
		for(Product product : products) {
			int col = 0;
			
			data[row][col] = product.getProductId();
			col++;
			
			data[row][col] = product.getName().toString();
			col++;
			
			data[row][col] = prices.get(row); // SHOULD BE PRICE
			col++;
			
			data[row][col] = product.getDescription().toString();
			col++;
			
			data[row][col] = false;
			row++;
		}
	

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        this.table = new JTable(model) {

            private static final long serialVersionUID = 1L;

            /*@Override
            public Class getColumnClass(int column) {
            return getValueAt(0, column).getClass();
            }*/
            @Override
            public Class getColumnClass(int column) {
                switch (column) {
                    case 0:
                    	return Integer.class;
                    case 1:
                    	return String.class;
                    case 2:
                    	return Float.class;
                    case 3:
                    	return String.class;
                    default:
                    	return Boolean.class;
                }
            }
        };
        this.table.setPreferredScrollableViewportSize(this.table.getPreferredSize());
                
        table.getModel().addTableModelListener(new TableModelListener() {
            @SuppressWarnings("unused")
			@Override
            public void tableChanged(TableModelEvent e) {
                 for(int i=0; i<table.getModel().getRowCount(); i++)
                    {
                	 

                      if ((Boolean) table.getModel().getValueAt(i,4) == true)
                      {  
                    	  int row = table.getSelectedRow();
                    	  int ID = (int) table.getModel().getValueAt(row, 0);
                    	  String name = (String) table.getModel().getValueAt(row, 1);
                    	  float nameShouldBePrice = (float) table.getModel().getValueAt(row, 2);
                    	  String description = (String) table.getModel().getValueAt(row, 3);
//                          System.out.print("ID: " + ID + " in ROW: ");
//                          System.out.println("\t"+table.getSelectedRow());
                          if(orderMap.containsKey(ID))
                        	  orderMap.remove(ID);
  	                  	  else
  	                  		orderMap.put(ID, new Product(ID, name, description));
  	                  	  System.out.println(orderMap.keySet());
                          break;
                 	  
                      }
                   }     
                }
        });
//        this.buttonSubmit.addActionListener();
        JScrollPane scrollPane = new JScrollPane(this.table);
        getContentPane().add(scrollPane);
        // adding it to JScrollPane
        JScrollPane sp = new JScrollPane(this.table);
        this.buttonSubmit = new JButton("Checkout Items");
		this.buttonSubmit.addActionListener(this);
		this.panel1 = new JPanel();
		this.panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.panel1.add(this.buttonSubmit);
		
		this.getContentPane().add(this.panel1, BorderLayout.NORTH);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(sp);
        // Frame Size
        this.setSize(500, 500);
        // Frame Visible = true
        this.setVisible(true);
        

    }

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == this.buttonSubmit) {
			ArrayList<Product> checkoutProducts = new ArrayList<Product>(this.orderMap.values());
			try {
				new OrderRegistration(checkoutProducts, this.broncoID, prices);
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dispose();
		}
		
	}
}