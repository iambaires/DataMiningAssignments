package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import testing.Customer;
import testing.DatabaseController;
import testing.Order;
import testing.Product;

public class OrderRegistration extends JFrame implements ActionListener{
	private JTable table;
	private JPanel panel1, panel2;
	
	OrderRegistration(ArrayList<Product> order, int broncoID, ArrayList<Float> prices) throws ClassNotFoundException, SQLException {
		
		this.setTitle(Integer.toString(broncoID));
		
		String[] columnNames = {"ID", "Name", "Price", "Description"};
		
		Object[][] data = new Object[order.size()][columnNames.length];

		int row = 0;
		
		float subtotal = 0;
		
		for(Product product : order) {
			int col = 0;
			
			data[row][col] = product.getProductId();
			col++;
			
			data[row][col] = product.getName().toString();
			col++;
			
			data[row][col] = prices.get(row); // SHOULD BE PRICE
			col++;
			
			subtotal += prices.get(row);
			
			data[row][col] = product.getDescription().toString();
			col++;
			
			row++;
		}
	

        DefaultTableModel model = new DefaultTableModel(data, columnNames);
        this.table = new JTable(model) {

            private static final long serialVersionUID = 1L;

            @Override
            public Class getColumnClass(int column) {
            	return getValueAt(0, column).getClass();
            
//            @Override
//            public Class getColumnClass(int column) {
//                switch (column) {
//                    case 0:
//                    	return Integer.class;
//                    case 1:
//                    	return String.class;
//                    case 2:
//                    	return String.class;
//                    case 3:
//                    	return String.class;
//                    default:
//                    	return Boolean.class;
//                }
            }
        };
        this.table.setPreferredScrollableViewportSize(this.table.getPreferredSize());
		JScrollPane scrollPane = new JScrollPane(this.table);
        getContentPane().add(scrollPane);
        // adding it to JScrollPane
        JScrollPane sp = new JScrollPane(this.table);
        this.panel1 = new JPanel();
		this.panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.panel2 = new JPanel();
		this.panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		
		
		DatabaseController dbc = DatabaseController.getInstance();
		int orderID = dbc.getOrder(" ").size();
		this.panel1.add(new JTextField("Order #" + orderID));
		this.panel1.add(new JTextField("Bronco ID #" + broncoID));
		this.panel2.add(new JTextField("Quantity:" + order.size()));
		this.panel2.add(new JTextField("Subtotal: $" + subtotal));
		
		ArrayList<Customer> customer = dbc.getCustomer(" WHERE bronco_id =" + broncoID);
		float discount = customer.get(0).getDiscount();
		this.panel2.add(new JTextField("Discount: " + String.format("%.2f", discount*100) + "%") );
		this.panel2.add(new JTextField("Total: $" + ((1-discount)*subtotal)));
		Order o = new Order(orderID, broncoID, "Ready");
		
		ArrayList<String[]> orderProducts = new ArrayList<String[]>();
		
		int index = 0;
		
		for(Product product : order) {
			String[] arr = {Integer.toString(product.getProductId()),  Float.toString(prices.get(index)), "1"};
			orderProducts.add(arr);
			index++;
		}
		
		dbc.registerNewOrder(o, orderProducts);
		
		this.getContentPane().add(panel1, BorderLayout.NORTH);
		this.getContentPane().add(panel2, BorderLayout.SOUTH);
		
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.add(sp);
        // Frame Size
        this.setSize(500, 500);
        // Frame Visible = true
        this.setVisible(true);
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		
	}

}
