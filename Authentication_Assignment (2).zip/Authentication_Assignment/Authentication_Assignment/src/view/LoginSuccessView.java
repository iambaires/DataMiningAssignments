package view;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.eclipse.jdt.internal.compiler.ast.ThisReference;

import model.dataccess.DataAccess;
import model.entities.MessageException;
import testing.Product;
import testing.DatabaseController;

public class LoginSuccessView extends JFrame implements ActionListener {
	
	private String userName;
	
	private JLabel lblUserName;
	
	private JTextField txtProductInfo;
	
	private JPanel panel1, panel2;
	
	private JButton buttonSubmit;
	
	private int broncoID;
	
	public LoginSuccessView (String userName, int broncoID) {		
		this.userName = userName;
		this.broncoID = broncoID;
		this.initializeComponents();
		this.buildUI();
	}
	
	private void initializeComponents() {
		this.lblUserName = new JLabel("Welcome " + this.userName + "!");
		
		this.panel1 = new JPanel();
		this.lblUserName.setFont(new Font("Arial",Font.PLAIN,25));
		this.panel1.setLayout(new FlowLayout(FlowLayout.CENTER));
		
		this.panel2 = new JPanel();
		this.panel2.setLayout(new FlowLayout(FlowLayout.CENTER));
		this.txtProductInfo = new JTextField(23);
		
		this.buttonSubmit = new JButton("Search Products");
		this.buttonSubmit.addActionListener(this);
	}
	
	private void buildUI() {
		this.panel1.add(this.lblUserName);
		
		this.panel2.add(this.txtProductInfo);
		
		this.panel2.add(this.buttonSubmit);
		
		this.getContentPane().add(panel1, BorderLayout.NORTH);
		this.getContentPane().add(panel2, BorderLayout.CENTER);
		this.setBounds(280,120,500,500);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == this.buttonSubmit) {
			DatabaseController dbc = DatabaseController.getInstance();
			try {
				
				String productInfo = this.txtProductInfo.getText();
				System.out.println(productInfo);
				
				if (productInfo.isBlank()) {
					throw new MessageException("Product Information not informed.");
				}
				
				System.out.println("BEFORE QUERY");
				
				ArrayList<Product> productData = new ArrayList<Product>();
				
								
				Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");

				boolean isNumericID = pattern.matcher(productInfo).matches();
				
				ArrayList<Product> products = new ArrayList<Product>();
							
				if(isNumericID) {
					String query = " WHERE product_id = " + productInfo;
					products = dbc.getProduct(query);
				}
				
				else {
					String query = " WHERE name LIKE '%" + productInfo +"%'";
					products = dbc.getProduct(query);
				}
				
				ArrayList<Float> prices = new ArrayList<Float>();
				for(Product product : products) {
					prices.add(dbc.getMostRecentPrice(product.getProductId()));
				}
				
				System.out.println(prices);
				
				new SearchResults(products, this.broncoID, prices);
				dispose();
				
				if (products.isEmpty())
					throw new MessageException("No products found.");
				
			} catch (MessageException e) {
				JOptionPane.showMessageDialog (null, e.getMessage());
			} catch (ClassNotFoundException e) {
				JOptionPane.showMessageDialog (null, e.getMessage());
			} catch (SQLException e) {
				JOptionPane.showMessageDialog (null, e.getMessage());
			}
		} else {
			this.txtProductInfo.setText("");
		}
	}

}
