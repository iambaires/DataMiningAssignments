package control;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.entities.MessageException;
import testing.Product;
import testing.DatabaseController;
import testing.Order;

@SuppressWarnings("serial")
public class OrderControl extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String address = "";
		
		DatabaseController dbc = DatabaseController.getInstance();
		
		try {
			
			String[] checked = request.getParameterValues("check");
			System.out.println("CHECK LEN:" +checked.length);
			
			String broncoID = request.getParameter("ID");
			request.setAttribute("ID", broncoID);	
			
			ArrayList<Product> orderedProducts = new ArrayList<Product>();
			ArrayList<Float> prices = new ArrayList<Float>();
			
			String[] ids = request.getParameterValues("ids");
			List<String> allIDs = Arrays.asList(ids);
			System.out.println(allIDs);
			
			String[] names = request.getParameterValues("names");		

			String[] descriptions = request.getParameterValues("descriptions");

			String[] itemPrices = request.getParameterValues("prices");
			
			float subtotal = 0;
			
			for(int i = 0; i < checked.length; i++) {
				System.out.println(checked[i]);
				if(allIDs.contains(checked[i])) {
					int index = allIDs.indexOf(checked[i]);
					int ID = Integer.parseInt(ids[index]);
					String name = names[index];
					float price = Float.parseFloat(itemPrices[index]);
					String description = descriptions[index];
					Product prod = new Product(ID, name, description);
					System.out.println(prod);
					orderedProducts.add(prod);
					prices.add(price);
					subtotal += price;
				}
				
			}
			
			System.out.println("PRICES" + prices);
			System.out.println("SUBTOTAL" + subtotal);
			
			int orderID = dbc.getOrder(" ").size();
			String query = " WHERE bronco_id = " + broncoID;
//			float d = dbc.getCustomer(query).get(0).getDiscount();
			float discount = 0f;
			
			String d = request.getParameter("discount");
			
			DecimalFormat df = new DecimalFormat("#.00"); 
			DecimalFormat percentDf = new DecimalFormat("#.0000"); 
			
			if(d != null) {
				discount = Float.valueOf(percentDf.format(Float.parseFloat(d)));
			}
			request.setAttribute("discount", discount*100);
			
			System.out.println("BID" + broncoID);
			System.out.println("DISCOUNT (OC)" + discount);
			
			request.setAttribute("products", orderedProducts);
			request.setAttribute("prices", prices);
			
			float total =  Float.valueOf(df.format(discount*subtotal));
			

			request.setAttribute("subtotal", subtotal);
			request.setAttribute("total", total);
			request.setAttribute("orderID", orderID);
			
//			for(Product product : orderedProducts) {
//				System.out.println(product);
//			}
			
			Order o = new Order(orderID, Integer.parseInt(broncoID), "Ready");
			
			ArrayList<String[]> orderProducts = new ArrayList<String[]>();
			
			int index = 0;
			
			for(Product product : orderedProducts) {
				String[] arr = {Integer.toString(product.getProductId()),  Float.toString(prices.get(index)), "1"};
				orderProducts.add(arr);
				index++;
			}
			
			dbc.registerNewOrder(o, orderProducts);
			
//			dbc.getCustomer(" ");
//			Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
//
//			boolean isNumericID = pattern.matcher(productInfo).matches();
//			
//			ArrayList<Product> products = new ArrayList<Product>();
//						
//			if(isNumericID) {
//				String query = " WHERE product_id = " + productInfo;
//				products = dbc.getProduct(query);
//			}
//			
//			else {
//				
//				String query = " WHERE name LIKE '%" + productInfo +"%'";
//				products = dbc.getProduct(query);
//			}
			
//			
//			if (products.isEmpty())
//				throw new MessageException("No products found.");
//			
//			request.setAttribute("products", products);
			
			address = "/view/OrderRegistration.jsp";
			

		} catch (MessageException e) {
			if (e.getMessage().equals("Product Information not informed.")) {
				System.out.println("Product Information not informed.");
				request.setAttribute("ErrorLogin", "Product Information not informed.");
				address = "/view/OrderRegistration.jsp";
			}	
			else if (e.getMessage().equals("No products found.")) {
				System.out.println("No products found.");
				request.setAttribute("ErrorLogin", "No products found.");
				address = "/view/OrderRegistration.jsp";	
		    }
		}
		catch (ClassNotFoundException e) {
			System.out.println("ClassNotFound");
			request.setAttribute("ErrorLogin", "Database connection failed.");
			address = "/view/OrderRegistration.jsp";
		} catch (SQLException e) {
			System.out.println("SQLException");
			request.setAttribute("ErrorLogin", "Database connection failed.");
			address = "/view/OrderRegistration.jsp";
		}
		
	    RequestDispatcher rd = request.getRequestDispatcher(address);
		rd.forward(request, response);
	}	
}
