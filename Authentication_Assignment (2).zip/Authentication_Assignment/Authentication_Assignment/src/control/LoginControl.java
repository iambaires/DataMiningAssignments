package control;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import model.business.LoginBusiness;
import model.entities.MessageException;

@SuppressWarnings("serial")
public class LoginControl extends HttpServlet {
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String address = "";
		String broncoID = "";
		String firstName = "";
		float discount = 0; 
		
		try {
	
			broncoID = request.getParameter("username");
			
			if (broncoID.isBlank()) {
				throw new MessageException("Bronco ID not informed.");
			}
			
			LoginBusiness instance = LoginBusiness.getInstance(Integer.valueOf(broncoID));
			
			ResultSet customerData = instance.verifyCredentials();
//			System.out.println(firstName);
			while(customerData.next()) {
				firstName = customerData.getString("first_name");
				discount = customerData.getFloat("discount");
				System.out.println("DISCOUNT (LC)" + discount);
			}
			
			if (firstName.isBlank()) {
//				System.out.println(firstName);
				throw new MessageException("Incorrect credentials.");
			}
			
			request.setAttribute("Username", firstName);
			request.setAttribute("ID", broncoID);
			request.setAttribute("discount", discount);
			address = "/view/LoginSuccessView.jsp";
		
			

		} catch (MessageException e) {
			if (e.getMessage().equals("Bronco ID not informed.")) {
				request.setAttribute("ErrorLogin", "Bronco ID not informed.");
				address = "/view/LoginView.jsp";
			}	
			else if (e.getMessage().equals("Incorrect credentials.")) {
				request.setAttribute("ErrorLogin", "Incorrect credentials.");
				address = "/view/LoginView.jsp";
		    }
		} catch (ClassNotFoundException e) {
//			System.out.println(e.toString());
			request.setAttribute("ErrorLogin", "Database connection failed.");
			
			address = "/view/LoginView.jsp";
		} catch (SQLException e) {
			System.out.println(e.toString());
			request.setAttribute("ErrorLogin", "Database connection failed.");
			address = "/view/LoginView.jsp";
		}
		
	    RequestDispatcher rd = request.getRequestDispatcher(address);
		rd.forward(request, response);

	}
	
}
