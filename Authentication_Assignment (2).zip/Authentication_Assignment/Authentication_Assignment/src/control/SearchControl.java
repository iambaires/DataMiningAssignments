package control;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Pattern;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.entities.MessageException;
import testing.Product;
import testing.DatabaseController;

@SuppressWarnings("serial")
public class SearchControl extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
		
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String address = "";
		
		DatabaseController dbc = DatabaseController.getInstance();
		
		try {
			
			String productInfo = request.getParameter("product");
			
			String broncoID = request.getParameter("ID");
			request.setAttribute("ID", broncoID);
			
			String discount = request.getParameter("discount");
			request.setAttribute("discount", discount);
			
			System.out.println("BID (SC)" + broncoID);
			System.out.println("DISCOUNT (SC)" + discount);
			
			Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");

			boolean isNumericID = pattern.matcher(productInfo).matches();
			
			ArrayList<Product> products = new ArrayList<Product>();
			ArrayList<Float> prices = new ArrayList<Float>();
						
			if(isNumericID) {
				String query = " WHERE product_id = " + productInfo;
				products = dbc.getProduct(query);
			}
			
			else {
				
				String query = " WHERE name LIKE '%" + productInfo +"%'";
				products = dbc.getProduct(query);
				
				for(Product product : products) {
					prices.add(dbc.getMostRecentPrice(product.getProductId()));
				}
			}
			
			if (products.isEmpty())
				throw new MessageException("No products found.");
			
			request.setAttribute("products", products);
			request.setAttribute("prices", prices);
			
			address = "/view/SearchResults.jsp";
			

		} catch (MessageException e) {
			if (e.getMessage().equals("Product Information not informed.")) {
				System.out.println("Product Information not informed.");
				request.setAttribute("ErrorLogin", "Product Information not informed.");
				address = "/view/SearchResults.jsp";
			}	
			else if (e.getMessage().equals("No products found.")) {
				System.out.println("No products found.");
				request.setAttribute("ErrorLogin", "No products found.");
				address = "/view/SearchResults.jsp";	
		    }
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFound");
			request.setAttribute("ErrorLogin", "Database connection failed.");
			address = "/view/SearchResults.jsp";
		} catch (SQLException e) {
			System.out.println("SQLException");
			request.setAttribute("ErrorLogin", "Database connection failed.");
			address = "/view/SearchResults.jsp";
		}
		
	    RequestDispatcher rd = request.getRequestDispatcher(address);
		rd.forward(request, response);
	}	
}
