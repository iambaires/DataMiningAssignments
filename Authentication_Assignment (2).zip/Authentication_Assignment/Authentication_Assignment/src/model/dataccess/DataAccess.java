package model.dataccess;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.regex.Pattern;

public class DataAccess {
	
private static DataAccess instance;
private Connection connection;

DataAccess() throws ClassNotFoundException, SQLException {
	final String URL = "jdbc:postgresql://localhost:5432/postgres";
//
	final String USER = "postgres";
//
	final String PWD = "8790";
//
	Class.forName("org.postgresql.Driver");
	
	this.connection = DriverManager.getConnection(URL, USER, PWD);
}

	public ResultSet verifyCredentials(int broncoID) throws ClassNotFoundException, SQLException {
	
//		System.out.println(broncoID);
		
		final PreparedStatement stmt = connection.prepareStatement("SELECT * FROM customer WHERE bronco_id=?");

		stmt.setInt(1, broncoID);

		ResultSet rs = stmt.executeQuery();

		return rs;
		
	}
		
//	public ResultSet getProducts(String info) throws NumberFormatException, SQLException {
//		
//		final PreparedStatement stmtWithID = connection.prepareStatement("SELECT * FROM products WHERE product_id=?");
//		final PreparedStatement stmtWithDescription = connection.prepareStatement("SELECT * FROM products WHERE ( LOWER(description) LIKE ?) OR (LOWER(product_name) LIKE ?)");
//		
//		Pattern pattern = Pattern.compile("-?\\d+(\\.\\d+)?");
//
//		boolean isNumericID = pattern.matcher(info).matches();
//		
//		System.out.print("QUERY SENT: ");
//		
//		if(isNumericID) {
//			System.out.println(info);
//			stmtWithID.setInt(1, Integer.parseInt(info));
//		}
//		
//		else {
//			info = "%"+info.toLowerCase()+"%";
//			System.out.println(info);
//			stmtWithDescription.setString(1, "%"+info+"%");
//			stmtWithDescription.setString(2, "%"+info+"%");
//		}
//
//		ResultSet rs = stmtWithDescription.executeQuery();
//		return rs;
//	}
	
	public static DataAccess getInstance() throws ClassNotFoundException, SQLException {
		if(instance == null) {
			instance = new DataAccess();
		}
		return instance;
	}

}

