package model.business;

import java.sql.ResultSet;
import java.sql.SQLException;

import model.dataccess.DataAccess;
import model.entities.MessageException;

public class LoginBusiness {
	
	private int broncoID;
	private static LoginBusiness instance;
	
	
	private LoginBusiness(int broncoID) {
		this.broncoID = broncoID;
	}
	
	public static LoginBusiness getInstance(int broncoID) {
		if(instance == null) {
			instance = new LoginBusiness(broncoID);
		}
		return instance;
	}
	
	public ResultSet verifyCredentials() throws ClassNotFoundException, SQLException {
		if (Integer.toString(this.broncoID).isBlank()) {
			throw new MessageException("Bronco ID not informed.");
		}
				
		return DataAccess.getInstance().verifyCredentials(this.broncoID);
	}
}
